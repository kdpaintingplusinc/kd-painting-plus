KD PAINTING PLUS INC. WEBSITE
Files:
- index.html — complete responsive website
- logo.svg — custom logo

Replace the three Unsplash image URLs in index.html with your own project photos when available.
The phone and email buttons are already configured.
